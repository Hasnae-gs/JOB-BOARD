<?php



namespace App\Http\Controllers;
use Auth;
use DB;
use App\User;
use App\Demande;
use App\Employeur;
use App\Candidat;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DemandeController extends Controller
{
    public function serchs()
    {
        $id= Auth::guard('employeur')->user()->id;
        $data=DB::table('demandes')
        ->join('candidats','demandes.id_candidat','=','candidats.id')
        ->join('offres','demandes.id_offre','=','offres.id_offre')
        ->select(
            'demandes.id_demande',
            'candidats.id',
            'candidats.name',
            'candidats.email',
            'candidats.prenom' 
            )
            ->where('demandes.etat','=',"en_cours")


            ->get();
          return view('candidatures',compact('data'));
  

    }

    public function postule(Request $request ,int $id_offre)
    {

        $id= Auth::guard('candidat')->user()->id;
        $demande = new demande();
        $demande->id_offre =$request->input("id_offre");
        $demande->id_candidat = $request->input("id");

    $demande->save();
    return view('jobpost');
  }

  


    public function accepter($idd)
{
  DB::table('demandes')
    ->where('id_demande', $idd)
    ->update(['etat' => 'Confirmé']);
    return redirect()->back()->with('message', 'demande bien acc');
}
public function refuser($idd)
{
 DB::table('demandes')
    ->where('id_demande', $idd)
    ->update(['etat' => 'Annulé']);
    return redirect()->back()->with('message', 'demande bien supp');
}


}