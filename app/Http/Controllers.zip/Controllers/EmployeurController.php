<?php

namespace App\Http\Controllers;
use Auth;
use DB;
use App\User;
use App\Employeur;
use App\Offre;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class EmployeurController extends Controller
{

    public function inf($id){
        $data=DB::table('employeurs')
        ->where('id','=',$id)

            ->select(
                'employeurs.logo',
                'employeurs.id',
                'employeurs.identifiant',
                'employeurs.raison_sosial',
                'employeurs.type_entreprise',
                'employeurs.secteur',
                'employeurs.ville',
                'employeurs.tele',
                'employeurs.site',
                'employeurs.poste',
                'employeurs.coordonnees',
                'employeurs.description',
                'employeurs.politique',
                'employeurs.accessibilite',
               
            )
            ->get();

            $dt=DB::table('employeurs')
            ->join('offres','employeurs.id','=','offres.id_employeur')
            ->where('id','=',$id)
            ->select(
                'offres.id_offre',
                'offres.date_depot',
                'offres.descriptif_poste' , 
                'offres.niveau_etude',
                'offres.domaine',
                'offres.niveau_experience',
                'offres.competence',
                'offres.qualite',
                'offres.langue',
                'offres.adresse',
                'offres.ville',
                'offres.region',
                'offres.poste_cadre',
                'offres.type_contrat', 
                'offres.debut_mission',
                'offres.procedure',
                'offres.id_offre'
            )
            ->get();

            return view('plusentreprises', compact('data','dt'));
}
          

}


