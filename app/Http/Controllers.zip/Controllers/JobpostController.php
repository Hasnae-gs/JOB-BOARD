<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
class JobpostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     
     *
     */

    public function post()
    {
        return view('jobpost');    

}
}